

<?php $__env->startSection('title', 'Add Subject'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Success/Error Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card" style="background-color: #fff; border: 1px solid #cddfff;">
        <div class="card-body">
            <h5 class="card-title">Add Subject</h5>

            <!-- Form to add new subject -->
            <form method="POST" action="<?php echo e(route('subjects.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="course_code" class="form-label">Subject Code</label>
                    <input type="text" class="form-control" id="course_code" name="course_code" required>
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">Subject Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>

    <!-- Table to list added subjects -->
    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title">Existing Subjects</h5>

            <!-- Table to display subjects -->
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Course Code</th>
                        <th>Subject Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($subject->course_code); ?></td>
                            <td><?php echo e($subject->name); ?></td>
                            <td>
                                <!-- Edit button (opens modal) -->
                                <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($subject->id); ?>">
                                    Edit
                                </button>
                                <!-- Delete button (opens modal) -->
                                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($subject->id); ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>

                        <!-- Edit Modal -->
                        <div class="modal fade" id="editModal<?php echo e($subject->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($subject->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalLabel<?php echo e($subject->id); ?>">Edit Subject</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Edit Subject Form -->
                                        <form method="POST" action="<?php echo e(route('subjects.update', $subject->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="mb-3">
                                                <label for="course_code" class="form-label">Subject Code</label>
                                                <input type="text" class="form-control" id="course_code" name="course_code" value="<?php echo e($subject->course_code); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="name" class="form-label">Subject Name</label>
                                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($subject->name); ?>" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Delete Modal -->
                        <div class="modal fade" id="deleteModal<?php echo e($subject->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($subject->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($subject->id); ?>">Confirm Deletion</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to delete the subject "<?php echo e($subject->name); ?>"?
                                    </div>
                                    <div class="modal-footer">
                                        <form action="<?php echo e(route('subjects.destroy', $subject->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u294699347/domains/classmonitoring.online/public_html/resources/views/subjects/addsubject.blade.php ENDPATH**/ ?>