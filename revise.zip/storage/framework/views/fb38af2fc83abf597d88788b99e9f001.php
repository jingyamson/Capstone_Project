<?php $__env->startSection('title', 'Enroll Students'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        body {
            background-color: #F6F9FF; /* Background color of the page */
        }

        .card {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .table {
            background-color: #ffffff; /* Table background */
        }

        .table th {
            background-color: #E3A833; /* Header background color */
            color: white; /* Header text color */
        }

        .table tbody tr:hover {
            background-color: #f0f0f0; /* Row hover effect */
        }

        .btn-primary {
            background-color: #E3A833; /* Primary button color */
            border-color: #E3A833; /* Border color for primary buttons */
        }

        .btn-danger {
            background-color: #ff4d4d; /* Danger button color */
            border-color: #ff4d4d; /* Border color for danger buttons */
        }
    </style>

    <div class="container">
    
        <div class="row">
            <div class="col-lg-12">
                <!-- Success message -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php elseif(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                

                <div class="card" style="background-color: #fff; border: 1px solid #cddfff;">
                    <div class="card-header">
                        <h5 class="card-title">Enroll Students - <?php echo e($subject->name); ?></h5>
                    </div>
                    <div class="card-body">
                    <form id="enrollForm" action="<?php echo e(route('subjects.enrolls')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                        <input type="hidden" name="enroll_type" id="enroll_type" value="single"> <!-- New hidden field -->
                        <div class="row mt-3">
                            <div class="col-4">
                                <select name="section_id" id="section" class="form-control" onchange="filterSection(this.value)">
                                    <option value="">Select Section</option>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-4">
                                <select name="student_id" id="student_id" class="form-control" onchange="setEnrollType(this.value)">
                                    <option value="">Select Student</option>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-4">
                                <!-- Button to trigger modal -->
                                <button type="submit" class="btn btn-primary mb-3">
                                    Enroll Student
                                </button>
                            </div>
                        </div>
                    </form>


                        <div class="row">
                            <div class="col-12">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Student Name</th>
                                            <th>Section</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($enroll->student->first_name); ?> <?php echo e($enroll->student->middle_name); ?> <?php echo e($enroll->student->last_name); ?></td>
                                                <td><?php echo e($enroll->student->section->name); ?></td>
                                                <td>
                                                <form action="<?php echo e(route('subjects.enrolls.destroy', $enroll->id)); ?>" method="POST" onsubmit="return confirmDelete();">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script>
        function filterSection(sectionID){
            const studentSelect = document.getElementById("student_id");
            studentSelect.innerHTML = '<option value="">Select Student</option>';
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if(sectionID == "<?php echo e($student->section_id); ?>") {
                    studentSelect.innerHTML += '<option value="<?php echo e($student->id); ?>"><?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?></option>';
                }else if(sectionID == "") {
                    studentSelect.innerHTML += '<option value="<?php echo e($student->id); ?>"><?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?></option>';
                }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            setEnrollType('');
        }
        function setEnrollType(studentID) {
            const enrollTypeField = document.getElementById('enroll_type');
            enrollTypeField.value = studentID ? 'single' : 'section'; // Set to 'single' if a student is selected, otherwise 'section'
        }
        function confirmDelete() {
            return confirm("Are you sure you want to delete this enrollment?");
        }
    </script>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u294699347/domains/classmonitoring.online/public_html/resources/views/subjects/enroll.blade.php ENDPATH**/ ?>