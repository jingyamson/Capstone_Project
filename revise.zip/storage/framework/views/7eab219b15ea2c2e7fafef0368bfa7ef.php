


<?php $__env->startSection('title', "Students in $section->name"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center mt-4">Students in <?php echo e($section->name); ?> - <?php echo e($section->description); ?></h3>

        <table class="table table-striped mt-3">
            <thead>
                <tr>
                    <th>Student Number</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($student->student_number); ?></td>
                        <td><?php echo e($student->first_name); ?></td>
                        <td><?php echo e($student->last_name); ?></td>
                        <td><?php echo e($student->gender); ?></td>
                        <td><?php echo e($student->date_of_birth); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">No students found in this section.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="<?php echo e(route('sections.index')); ?>" class="btn btn-secondary mt-3">Back to Sections</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Christine Yamson\Desktop\Capstone\Capstone-Project-main-main\resources\views/sections/students.blade.php ENDPATH**/ ?>