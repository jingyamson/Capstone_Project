

<?php $__env->startSection('title', 'Group Shuffling'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">

    <!-- Display Validation Errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Group Shuffling Section -->
    <div class="card mb-4" style="background-color: #ffffff;">
        <div class="card-header text-center">
            <h4 class="card-title">Group Shuffling</h4>
        </div>
        <div class="card-body">
            <br>
            <form action="<?php echo e(route('students.group.shuffle')); ?>" method="POST">
                <?php echo csrf_field(); ?> <!-- This is necessary for CSRF protection -->
                <div class="form-group">
                    <label for="subject">Select Subject:</label>
                    <select class="form-control" id="subject" name="subject_id">
                        <option value="">All Subjects</option>
                        <?php if(isset($subjects)): ?>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->subject_id); ?>" <?php echo e(isset($subjectId) && $subjectId == $subject->subject_id ? 'selected' : ''); ?>><?php echo e($subject->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="section">Select Section:</label>
                    <select class="form-control" id="section" name="section_id">
                        <option value="">All Sections</option>
                        <?php if(isset($sections)): ?>
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($section->id); ?>" <?php echo e(isset($sectionId) && $sectionId == $section->id ? 'selected' : ''); ?>>
                                    BSIT - <?php echo e($section->name); ?><?php echo e($section->description); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="students_per_group">Number of Students Per Group:</label>
                    <input type="number" class="form-control" id="students_per_group" name="students_per_group" min="1" value="1" required>
                </div>
                <br>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="background-color:#E3A833;border-color: #E3A833;">Shuffle into Groups</button>
                </div>
            </form>

            <h5 class="mt-4" style="color: #E3A833;">Student Groups:</h5>
            <!-- Table to display groups -->
            <?php if(isset($groups) && count($groups) > 0): ?>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h6 style="color: #E3A833;">Group <?php echo e($index + 1); ?></h6>
                    <table class="table table-bordered mt-3" style="background-color: #ffffff;">
                        <thead>
                            <tr>
                                <th class="col-1">Count</th>
                                <th class="col-2">Student Number</th>
                                <th class="col-2">Student Name</th>
                                <th class="col-1">Section</th>
                                <th class="col-1">Subject</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($group) > 0): ?>
                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($student->student->student_number); ?></td>
                                        <td><?php echo e($student->student->last_name); ?>, <?php echo e($student->student->first_name); ?> <?php echo e($student->student->middle_name); ?></td>
                                        <td>BSIT - <?php echo e($student->section->name); ?><?php echo e($student->section->description); ?></td>
                                        <td><?php echo e($student->subject->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7">No students found in this group.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No groups created yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u294699347/domains/classmonitoring.online/public_html/resources/views/student/group_shuffle.blade.php ENDPATH**/ ?>