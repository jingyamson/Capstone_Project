<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    

</head>
<body>

    <!-- ======= Header ======= -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Header -->
  
    <!-- ======= Sidebar ======= -->
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main id="main" class="main">
  
      <section class="section">
        <?php echo $__env->yieldContent('content'); ?>
      </section>
  
    </main><!-- End #main -->
  
    <!-- ======= Footer ======= -->
<footer id="footer" class="footer">
  <div class="row">
    <div class="col-12 text-center">
      <img src="<?php echo e(asset('assets/img/dct.svg')); ?>" alt="logo" height="100" width="100">
      <img src="<?php echo e(asset('assets/img/ccs.png')); ?>" alt="logo" height="100" width="100">
    </div>
  </div>
  <div class="copyright">
    <strong>DOMINICAN COLLEGE OF TARLAC</strong>
  </div>
  <div class="credits">
    A.Y: <span id="academic-year"></span>
  </div>
</footer><!-- End Footer -->

<script>
  function getAcademicYear() {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();

    let startYear, endYear;


    if (currentMonth < 6) {
      startYear = currentYear - 1;
      endYear = currentYear;
    } else {
      startYear = currentYear;
      endYear = currentYear + 1;
    }

    return `${startYear} - ${endYear}`;
  }

  document.getElementById("academic-year").textContent = getAcademicYear();
</script>


    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\Christine Yamson\Desktop\Capstone\Capstone-Project-main-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>