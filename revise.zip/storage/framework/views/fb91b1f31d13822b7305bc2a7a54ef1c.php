

<?php $__env->startSection('title', 'Attendance'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .square-table td {
        width: 100px;
        height: 50px;
        text-align: center;
        vertical-align: middle; /* Aligns content vertically */
    }
    .table .hover:hover {
        background-color: wheat;
        cursor: pointer;
    }
</style>
<div class="container mt-5">
        <form action="<?php echo e(route('attendance.index')); ?>" method="GET">
            <div class="row mb-4">
                <!-- Student Filter -->
                <input type="hidden" id="subject_id" name="subject_id" value="<?php echo e($subjectId); ?>">
                <div class="col-md-3">
                    <h3>
                        <strong><?php echo e($subjectName); ?></strong>
                    </h3>
                </div>
                <div class="col-md-3">
                    <label for="section_id">Select Section:</label>
                    <select name="section_id" id="section_id" class="form-control" onchange="filterStudents()">
                        <option value="">All Sections</option>
                        <?php if(isset($sections)): ?>
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($section->id); ?>" <?php echo e(request('section_id') == $section->id ? 'selected' : ($student->section->id == $section->id ? 'selected' : '')); ?>>
                                    BSIT - <?php echo e($section->name); ?><?php echo e($section->description); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="student_id">Select Student:</label>
                    <select name="student_id" id="student_id" class="form-control">
                        <option value="">Select Student</option>
                        <?php $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolled): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($enrolled->student->id); ?>" <?php echo e(request('student_id') == $enrolled->student->id ? 'selected' : ($student->id == $enrolled->student->id ? 'selected' : '')); ?>>
                                <?php echo e($enrolled->student->first_name); ?> <?php echo e($enrolled->student->middle_name); ?> <?php echo e($enrolled->student->last_name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary btn-block">Filter</button>
                </div>
            </div>
        </form>

        <!-- Student Information Section -->
        <?php if(isset($message)): ?>
            <div class="card text-center mt-4">
                <div class="card-body">
                    <h5 class="card-title">No Students Found</h5>
                    <p class="card-text"><?php echo e($message); ?></p>
                </div>
            </div>
        <?php else: ?>
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card p-3">
                    <h5 class="mb-3">Student Information</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Name:</strong> <?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?></p>
                        </div>
                        <div class="col-md-3">
                            <p><strong>Gender:</strong> <?php echo e($student->gender); ?></p>
                        </div>
                        <div class="col-md-3">
                            <p><strong>Course:</strong> <?php echo e($student->course); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Section:</strong> BSIT - <?php echo e($student->section->name); ?><?php echo e($student->section->description); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<!-- Attendance Type Selection Dropdown -->
<div class="row mb-4">
    <!-- Attendance Type Selection -->
    <div class="col-md-4">
        <label for="attendanceType">Select Attendance Type:</label>
        <select id="attendanceType" class="form-control">
            <option value="both">Both</option>
            <option value="lecture">Lecture Only</option>
            <option value="laboratory">Laboratory Only</option>
        </select>
    </div>

        <!-- Lecture Attendance Table -->
        <div id="lectureAttendance" class="attendance-table">
            <h4>Lecture Attendance</h4>
            <div style="overflow-x:auto;">
                <table class="table table-bordered">
                    <thead>
                        <tr class="text-center">
                            <th>Days</th>
                            <?php for($i = 1; $i <= 18; $i++): ?>
                                <th><?php echo e($i); ?></th>
                            <?php endfor; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = ['Mon' => 1, 'Tue' => 2, 'Wed' => 3, 'Thu' => 4, 'Fri' => 5, 'Sat' => 6]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $dayNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="square-table">
                                <td><?php echo e($day); ?></td>
                                <?php for($i = 1; $i <= 18; $i++): ?>
                                    <?php
                                        // Check for existing attendance record for this day and date
                                        $attendance = $attendanceRecords
                                            ->where('day', $dayNum)
                                            ->where('type', 1)
                                            ->where('attendance_date', $i)
                                            ->first();
                                    ?>
                                    <td id="lec-<?php echo e($day); ?>-<?php echo e($i); ?>" 
                                        class="hover"
                                        data-day="<?php echo e($dayNum); ?>" 
                                        data-type="1" 
                                        data-attendance-date="<?php echo e($i); ?>" 
                                        ondblclick="deleteAttendance(1, <?php echo e($dayNum); ?>, <?php echo e($i); ?>)"
                                        onclick="checkAttendance(1, <?php echo e($dayNum); ?>, <?php echo e($i); ?>, <?php echo e($attendance ? ($attendance->status == 1 ? 2 : 1) : 1); ?>)"
                                        style="background-color: <?php echo e($attendance ? ($attendance->status == 1 ? 'Blue' : 'Red') : ''); ?>;">
                                    </td>
                                <?php endfor; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Laboratory Attendance Table -->
        <div id="laboratoryAttendance" class="attendance-table" style="display: none;">
            <h4>Laboratory Attendance</h4>
            <div style="overflow-x:auto;">
                <table class="table table-bordered">
                    <thead>
                        <tr class="text-center">
                            <th>Days</th>
                            <?php for($i = 1; $i <= 18; $i++): ?>
                                <th><?php echo e($i); ?></th>
                            <?php endfor; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = ['Mon' => 1, 'Tue' => 2, 'Wed' => 3, 'Thu' => 4, 'Fri' => 5, 'Sat' => 6]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day1 => $dayNumLab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="square-table">
                                <td><?php echo e($day1); ?></td>
                                <?php for($j = 1; $j <= 18; $j++): ?>
                                    <?php
                                        // Check for existing attendance record for laboratory
                                        $attendance_lab = $labAttendanceRecords
                                            ->Where('day', $dayNumLab)
                                            ->Where('type', 2)
                                            ->firstWhere('attendance_date', $j);
                                    ?>
                                    <td id="lab-<?php echo e($day); ?>-<?php echo e($j); ?>" 
                                        class="hover"
                                        data-day="<?php echo e($dayNum); ?>" 
                                        data-type="2" 
                                        data-attendance-date="<?php echo e($j); ?>" 
                                        ondblclick="deleteAttendance(2, <?php echo e($dayNumLab); ?>, <?php echo e($j); ?>)"
                                        onclick="checkAttendance(2, <?php echo e($dayNumLab); ?>, <?php echo e($j); ?>, <?php echo e($attendance_lab ? ($attendance_lab->status == 1 ? 2 : 1) : 1); ?>)"
                                        style="background-color: <?php echo e($attendance_lab ? ($attendance_lab->status == 1 ? 'Blue' : 'Red') : ''); ?>;">
                                    </td>
                                <?php endfor; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <!-- Navigation Arrows -->
    <div class="row mt-4 text-center">
        <div class="col">
            <a href="<?php echo e(route('attendance.index', ['student_id' => $prevStudentId, 'subject_id' => $subjectId])); ?>" class="btn btn-secondary">&lt;</a>
            <a href="<?php echo e(route('attendance.index', ['student_id' => $nextStudentId, 'subject_id' => $subjectId])); ?>" class="btn btn-secondary">&gt;</a>
        </div>
    </div>
</div>

<script>
    // JavaScript to handle the dropdown change event
    document.getElementById('attendanceType').addEventListener('change', function() {
        const selectedType = this.value;

        
        // Hide all attendance tables initially
        document.querySelectorAll('.attendance-table').forEach(table => {
            table.style.display = 'none';
        });
        
        // Show the selected attendance table(s)
        if (selectedType === 'lecture') {
            document.getElementById('lectureAttendance').style.display = 'block';
        } else if (selectedType === 'laboratory') {
            document.getElementById('laboratoryAttendance').style.display = 'block';
        } else {
            document.getElementById('lectureAttendance').style.display = 'block';
            document.getElementById('laboratoryAttendance').style.display = 'block';
        }
    });
    
    // Trigger change event on page load to set the default view
    document.getElementById('attendanceType').dispatchEvent(new Event('change'));
</script>
<script>
    function checkAttendance(type, day, attendanceDate, status) {
        const studentId = <?php echo e($student->id); ?>;
        const subjectId = <?php echo e($subjectId); ?>;
        const sectionId = <?php echo e($student->section->id); ?>;

        // Fetch request to store attendance
        fetch('<?php echo e(route('attendance.store')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({
                    student_id: studentId,
                    subject_id: subjectId,
                    section_id: sectionId,
                    day: day,
                    type: type,
                    status: status,
                    attendance_date: attendanceDate // Match this with the back-end
                })
            })
            .then(response => response.json())
            .then(data => {
                console.log(data); // Handle success response
                if (data.success) {
                    const redirectUrl = '<?php echo e(route('attendance.index', ['student_id' => $student->id, 'subject_id' => $subjectId, 'type' => ' + type + '])); ?>';

                    // JavaScript redirection
                    window.location.href = redirectUrl;
                } else {
                    alert(data.error); // Handle any errors returned from the server
                }
            })
            .catch(error => {
                console.error('Error:', error); // Handle error response
            });
    }


    function deleteAttendance(type, day, attendanceDate) {
        const studentId = <?php echo e($student->id); ?>;
        const subjectId = <?php echo e($subjectId); ?>;
        const sectionId = <?php echo e($student->section->id); ?>;

        if (confirm('Are you sure you want to delete this attendance?')) {
            fetch('<?php echo e(route('attendance.delete')); ?>', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({
                    student_id: studentId,
                    subject_id: subjectId,
                    section_id: sectionId,
                    day: day,
                    type: type,
                    attendance_date: attendanceDate
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.error);    // Show any errors from the server
                }
            })
            .catch(error => {
                console.error('Error:', error);  // Handle network or other errors
            });
        }
    }
</script>
<script>
    // Function to toggle the visibility of lecture and laboratory tables
    function toggleAttendanceTables(selectedType) {
        const lectureDiv = document.getElementById('lectureAttendance');
        const laboratoryDiv = document.getElementById('laboratoryAttendance');

        if (selectedType === 'both') {
            // Show both
            lectureDiv.style.display = 'block';
            laboratoryDiv.style.display = 'block';
        } else if (selectedType === 'lecture') {
            // Show lecture, hide laboratory
            lectureDiv.style.display = 'block';
            laboratoryDiv.style.display = 'none';
        } else if (selectedType === 'laboratory') {
            // Show laboratory, hide lecture
            lectureDiv.style.display = 'none';
            laboratoryDiv.style.display = 'block';
        }
    }

    // Event listener for the dropdown change
    document.getElementById('attendanceType').addEventListener('change', function() {
        const selectedValue = this.value;

        // Save the selected value to localStorage
        localStorage.setItem('attendanceType', selectedValue);

        // Toggle tables based on the selected value
        toggleAttendanceTables(selectedValue);
    });

    // On page load, set the tables according to the stored value
    window.addEventListener('DOMContentLoaded', function() {
        const savedType = localStorage.getItem('attendanceType') || 'both';
        document.getElementById('attendanceType').value = savedType;

        // Initialize the attendance tables based on the saved value
        toggleAttendanceTables(savedType);
    });
</script>

<script src="<?php echo e(asset('js/attendance.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u294699347/domains/classmonitoring.online/public_html/resources/views/attendance/index.blade.php ENDPATH**/ ?>